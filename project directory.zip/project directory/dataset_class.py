from global_var import *

#this is a class used to store and manipulate the picos' connection and its status
class dataset:
    
    data = [[0],[0]]

    #object instantiation
    def __init__(self,Name,Num_points):
        #assign object attributes
        self.name = Name
        self.num_points = Num_points
        

    def __str__(self): #returns object as a string
        return str(str(self.Name) + str(self.num_points))

    #dataset handling
    #add a point to the dataset
    def addData(self,x,y):
        #ensure dataset does not contain more points than allowed
        if self.data[0].__len__() >= self.num_points:
            self.data[0].append(x)
            self.data[1].append(y)

            #remove first point
            self.data[0].pop(0)
            self.data[1].pop(0)

        else:
            #just add the new point
            self.data[0].append(x)
            self.data[1].append(y)