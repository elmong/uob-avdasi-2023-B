import sys
import time
import numpy as np
from datetime import datetime
from bokeh.io import output_notebook
from bokeh.plotting import figure
from bokeh.io import show , curdoc
from bokeh.io import push_notebook
from bokeh.models import ColumnDataSource, Legend, CustomJS, Select
from bokeh.server.server import Server

import dataset_class
from global_var import control_surfaces

#constants

POINTS_STORED = 400

#------functions used------#
def bkapp(doc):
    df = sea_surface_temperature.copy()
    source = ColumnDataSource(data=df)

    plot = figure(x_axis_type='datetime', y_range=(0, 25), y_axis_label='Temperature (Celsius)',
                  title="Sea Surface Temperature at 43.18, -70.43")
    plot.line('time', 'temperature', source=source)

    def callback(attr, old, new):
        if new == 0:
            data = df
        else:
            data = df.rolling(f"{new}D").mean()
        source.data = ColumnDataSource.from_df(data)

    slider = Slider(start=0, end=30, value=0, step=1, title="Smoothing by N Days")
    slider.on_change('value', callback)

    doc.add_root(column(slider, plot))

server = Server({'/': bkapp}, num_procs=1)
server.start()

if __name__ == '__main__':
    print('Opening Bokeh application on http://localhost:5006/')

    server.io_loop.add_callback(server.show, "/")
    server.io_loop.start()

#---------Main code--------#

#declare each control surface dataset
elevator_pico_angle = dataset_class.dataset("Elevator Pico Angle",POINTS_STORED)
rudder_pico_angle = dataset_class.dataset("Rudder Pico Angle",POINTS_STORED)

port_aileron_pico_angle = dataset_class.dataset("Port Aileron Pico Angle",POINTS_STORED)
port_flap_pico_angle = dataset_class.dataset("Port Flap Pico Angle",POINTS_STORED)

starboard_aileron_pico_angle = dataset_class.dataset("Starboard Aileron Pico Angle",POINTS_STORED)
starboard_flap_pico_angle = dataset_class.dataset("Starboard Flap Pico Angle",POINTS_STORED)


#create columnDataSource
elevator_pico_angleDS = ColumnDataSource(data = {"x": elevator_pico_angle.data[0], "y": elevator_pico_angle.data[1]})
rudder_pico_angleDS = ColumnDataSource(data = {"x": rudder_pico_angle.data[0], "y": rudder_pico_angle.data[1]})
port_aileron_pico_angleDS = ColumnDataSource(data = {"x": port_aileron_pico_angle.data[0], "y": port_aileron_pico_angle.data[1]})
port_flap_pico_angleDS = ColumnDataSource(data = {"x": port_flap_pico_angle.data[0], "y": port_flap_pico_angle.data[1]})
starboard_aileron_pico_angleDS = ColumnDataSource(data = {"x": starboard_aileron_pico_angle.data[0], "y": starboard_aileron_pico_angle.data[1]})
starboard_flap_pico_angleDS = ColumnDataSource(data = {"x": starboard_flap_pico_angle.data[0], "y": starboard_flap_pico_angle.data[1]})


def update_data_dictionaries():
    #update datasets of each control surface
    global elevator_pico_angle
    global rudder_pico_angle
    global port_aileron_pico_angle
    global port_flap_pico_angle
    global starboard_aileron_pico_angle
    global starboard_flap_pico_angle

    elevator_pico_angle.addData(np.random.random(),control_surfaces["elevator"]["angle"])
    rudder_pico_angle.addData(np.random.random(),control_surfaces["rudder"]["angle"])
    port_aileron_pico_angle.addData(np.random.random(),control_surfaces['port_aileron']['angle'])
    port_flap_pico_angle.addData(np.random.random(),control_surfaces['port_flap']['angle'])
    starboard_aileron_pico_angle.addData(np.random.random(),control_surfaces['starboard_aileron']['angle'])
    starboard_flap_pico_angle.addData(np.random.random(),control_surfaces['starboard_flap']['angle'])


    #update dictionaries
    global elevator_pico_angleDS
    global rudder_pico_angleDS
    global port_aileron_pico_angleDS
    global port_flap_pico_angleDS
    global starboard_aileron_pico_angleDS
    global starboard_flap_pico_angleDS

    
    # elevator_pico_angleDS.data = {"x": elevator_pico_angle.data[0], "y": elevator_pico_angle.data[1]}
    # rudder_pico_angleDS.data = {"x": rudder_pico_angle.data[0], "y": rudder_pico_angle.data[1]}
    # port_aileron_pico_angleDS.data = {"x": port_aileron_pico_angle.data[0], "y": port_aileron_pico_angle.data[1]}
    # port_flap_pico_angleDS.data = {"x": port_flap_pico_angle.data[0], "y": port_flap_pico_angle.data[1]}
    # starboard_aileron_pico_angleDS.data = {"x": starboard_aileron_pico_angle.data[0], "y": starboard_aileron_pico_angle.data[1]}
    # starboard_flap_pico_angleDS.data = {"x": starboard_flap_pico_angle.data[0], "y": starboard_flap_pico_angle.data[1]}

    elevator_pico_angleDS.stream({"x": elevator_pico_angle.data[0], "y": elevator_pico_angle.data[1]}, POINTS_STORED)
    rudder_pico_angleDS.stream( {"x": rudder_pico_angle.data[0], "y": rudder_pico_angle.data[1]}, POINTS_STORED)
    port_aileron_pico_angleDS.stream( {"x": port_aileron_pico_angle.data[0], "y": port_aileron_pico_angle.data[1]}, POINTS_STORED)
    port_flap_pico_angleDS.stream( {"x": port_flap_pico_angle.data[0], "y": port_flap_pico_angle.data[1]}, POINTS_STORED)
    starboard_aileron_pico_angleDS.stream( {"x": starboard_aileron_pico_angle.data[0], "y": starboard_aileron_pico_angle.data[1]}, POINTS_STORED)
    starboard_flap_pico_angleDS.stream( {"x": starboard_flap_pico_angle.data[0], "y": starboard_flap_pico_angle.data[1]}, POINTS_STORED)
    print(elevator_pico_angleDS.data)

    


fig = figure()
fig.line(x="x", y="y", line_color="tomato", line_width=10.0, source=elevator_pico_angleDS)
fig.line(x="x", y="y", line_color="tomato", line_width=1.0, source=rudder_pico_angleDS)
fig.line(x="x", y="y", line_color="tomato", line_width=1.0, source=port_aileron_pico_angleDS)
fig.line(x="x", y="y", line_color="tomato", line_width=1.0, source=port_flap_pico_angleDS)
fig.line(x="x", y="y", line_color="tomato", line_width=1.0, source=starboard_aileron_pico_angleDS)
fig.line(x="x", y="y", line_color="tomato", line_width=1.0, source=starboard_flap_pico_angleDS)


show(fig)



while True: 
    update_data_dictionaries()
    
    time.sleep(1)
